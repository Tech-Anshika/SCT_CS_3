#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      anshika tyagi
#
# Created:     13-07-2024
# Copyright:   (c) anshi 2024
# Licence:     <your licence>
#-------------------------------------------------------------------------------
diction= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
def userInterface():
    fin = open('C:/Users/anshi/OneDrive/Documents/caear/message.txt', 'r')
    fout = open('C:/Users/anshi/OneDrive/Documents/caear/cipher.txt', 'w')
    container = fin.readlines()
    message = ''.join(container)
    message = message.replace(" ", "")
    message = message.upper()

    userInput = input("Welcome \n (type 'e' for encryption)\n (type 'd' for decryption)\n")

    if userInput == "e":
        print("Enter the key value")
        key = int(input())
        fout.write(Encrypt(message, key) + '\n')
    elif userInput == "d":
        print("Enter the key value")
        key = int(input())
        fout.write(Decrypt(message, key) + '\n')
    else:
        print("Entered choice is wrong")
        userInterface()

    fin.close()
    fout.close()

def Encrypt(message, key):
    diction = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    encrypted_message = ""
    for i in message:
        if i in diction:
            location = key + diction.index(i)
            location %= 26
            encrypted_message += diction[location]
        else:
            encrypted_message += i
    print("Encryption is complete\n please check the cipher.txt")
    return encrypted_message

def Decrypt(message, key):
    diction = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    decrypted_message = ""
    for i in message:
        if i in diction:
            location = diction.index(i) - key
            location %= 26
            decrypted_message += diction[location]
        else:
            decrypted_message += i
    print("Decryption is complete\n please check the cipher.txt")
    return decrypted_message

userInterface()
